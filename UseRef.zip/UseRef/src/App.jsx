import React from 'react'
import NumericInputWithRenderCount from './components/NumForm'

export default function App() {
  return (
    <div>
      <NumericInputWithRenderCount/>
    </div>
  )
}
